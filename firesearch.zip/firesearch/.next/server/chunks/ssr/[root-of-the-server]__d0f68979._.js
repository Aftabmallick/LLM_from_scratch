module.exports = {

"[externals]/async_hooks [external] (async_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("async_hooks", () => require("async_hooks"));

module.exports = mod;
}}),
"[externals]/util [external] (util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/assert [external] (assert, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}}),
"[externals]/tty [external] (tty, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}}),
"[externals]/os [external] (os, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[project]/lib/firecrawl.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/no-explicit-any */ __turbopack_context__.s({
    "FirecrawlClient": (()=>FirecrawlClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mendable$2f$firecrawl$2d$js$2f$dist$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mendable/firecrawl-js/dist/index.js [app-rsc] (ecmascript)");
;
class FirecrawlClient {
    client;
    constructor(providedApiKey){
        const apiKey = providedApiKey || process.env.FIRECRAWL_API_KEY;
        if (!apiKey) {
            throw new Error('FIRECRAWL_API_KEY is required - either provide it or set it as an environment variable');
        }
        this.client = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mendable$2f$firecrawl$2d$js$2f$dist$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]({
            apiKey
        });
    }
    async scrapeUrl(url, timeoutMs = 15000) {
        try {
            // Create a timeout promise
            const timeoutPromise = new Promise((_, reject)=>{
                setTimeout(()=>reject(new Error('Scraping timeout')), timeoutMs);
            });
            // Race the scraping against the timeout
            const scrapePromise = this.client.scrapeUrl(url, {
                formats: [
                    'markdown',
                    'html'
                ]
            });
            const result = await Promise.race([
                scrapePromise,
                timeoutPromise
            ]);
            if ('success' in result && !result.success) {
                throw new Error(result.error || 'Scrape failed');
            }
            return {
                markdown: result.markdown || '',
                html: result.html || '',
                metadata: result.metadata || {},
                success: true
            };
        } catch (error) {
            // Handle timeout errors
            if (error?.message === 'Scraping timeout') {
                return {
                    markdown: '',
                    html: '',
                    metadata: {
                        error: 'Scraping took too long and was stopped',
                        timeout: true
                    },
                    success: false,
                    error: 'timeout'
                };
            }
            // Handle 403 errors gracefully
            if (error?.statusCode === 403 || error?.message?.includes('403')) {
                return {
                    markdown: '',
                    html: '',
                    metadata: {
                        error: 'This website is not supported by Firecrawl',
                        statusCode: 403
                    },
                    success: false,
                    error: 'unsupported'
                };
            }
            // Return error info for other failures
            return {
                markdown: '',
                html: '',
                metadata: {
                    error: error?.message || 'Failed to scrape URL',
                    statusCode: error?.statusCode
                },
                success: false,
                error: 'failed'
            };
        }
    }
    async mapUrl(url, options) {
        try {
            const result = await this.client.mapUrl(url, {
                search: options?.search,
                limit: options?.limit || 10
            });
            if ('success' in result && !result.success) {
                throw new Error(result.error || 'Map failed');
            }
            return {
                links: result.links || [],
                metadata: result.metadata || {}
            };
        } catch (error) {
            throw error;
        }
    }
    async search(query, options) {
        try {
            // Search with scrape - this gets us content immediately!
            const searchParams = {
                limit: options?.limit || 10
            };
            // Add scrapeOptions to get content with search results
            if (options?.scrapeOptions !== false) {
                searchParams.scrapeOptions = {
                    formats: [
                        'markdown'
                    ],
                    ...options?.scrapeOptions
                };
            }
            const result = await this.client.search(query, searchParams);
            // Handle the actual Firecrawl v1 API response format
            if (result && typeof result === 'object' && 'success' in result) {
                if (!result.success) {
                    throw new Error(result.error || 'Search failed');
                }
            }
            // Extract data - search with scrape returns data with content
            const data = result?.data || [];
            // Transform to include scraped content
            const enrichedData = data.map((item)=>{
                // Try to extract favicon from metadata or construct default
                let favicon = item.metadata?.favicon || null;
                if (!favicon && item.metadata?.ogImage) {
                    favicon = item.metadata.ogImage;
                } else if (!favicon && item.url) {
                    // Default favicon URL
                    const domain = new URL(item.url).hostname;
                    favicon = `https://${domain}/favicon.ico`;
                }
                return {
                    url: item.url,
                    title: item.title || item.metadata?.title || 'Untitled',
                    description: item.description || item.metadata?.description || '',
                    markdown: item.markdown || '',
                    html: item.html || '',
                    links: item.links || [],
                    screenshot: item.screenshot || null,
                    metadata: {
                        ...item.metadata,
                        favicon: favicon,
                        screenshot: item.screenshot
                    },
                    scraped: true,
                    content: item.markdown || '',
                    favicon: favicon // Add at top level for easy access
                };
            });
            return {
                data: enrichedData,
                results: enrichedData,
                metadata: result?.metadata || {}
            };
        } catch (error) {
            throw error;
        }
    }
}
}}),
"[externals]/node:crypto [external] (node:crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}}),
"[project]/lib/context-processor.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ContextProcessor": (()=>ContextProcessor)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$openai$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/openai/dist/index.mjs [app-rsc] (ecmascript)");
;
;
class ContextProcessor {
    // Configuration
    MAX_TOTAL_CHARS = 100000;
    MIN_CHARS_PER_SOURCE = 2000;
    MAX_CHARS_PER_SOURCE = 15000;
    CONTEXT_WINDOW_SIZE = 500;
    /**
   * Process sources for optimal context selection
   */ async processSources(query, sources, searchQueries, onProgress) {
        // Determine summary length based on number of sources
        const summaryLength = this.calculateSummaryLength(sources.length);
        // Process sources with GPT-4o-mini summarization
        const processedSources = await Promise.all(sources.map((source)=>this.summarizeSource(source, query, searchQueries, summaryLength, onProgress)));
        // Filter out failed sources and sort by relevance
        const validSources = processedSources.filter((s)=>s.relevanceScore > 0).sort((a, b)=>b.relevanceScore - a.relevanceScore);
        return validSources;
    }
    /**
   * Extract keywords from query and search queries
   */ extractKeywords(query, searchQueries) {
        const allText = [
            query,
            ...searchQueries
        ].join(' ').toLowerCase();
        // Remove common words
        const stopWords = new Set([
            'the',
            'a',
            'an',
            'and',
            'or',
            'but',
            'in',
            'on',
            'at',
            'to',
            'for',
            'of',
            'with',
            'by',
            'from',
            'as',
            'is',
            'was',
            'are',
            'were',
            'been',
            'be',
            'have',
            'has',
            'had',
            'do',
            'does',
            'did',
            'will',
            'would',
            'could',
            'should',
            'may',
            'might',
            'must',
            'can',
            'what',
            'when',
            'where',
            'how',
            'why',
            'who'
        ]);
        // Extract words, filter stopwords, and get unique keywords
        const words = allText.split(/\W+/).filter((word)=>word.length > 2 && !stopWords.has(word));
        // Also extract quoted phrases
        const quotedPhrases = allText.match(/"([^"]+)"/g)?.map((p)=>p.replace(/"/g, '')) || [];
        return [
            ...new Set([
                ...words,
                ...quotedPhrases
            ])
        ];
    }
    /**
   * Process a single source to extract relevant sections and calculate relevance
   */ async processSource(source, keywords) {
        if (!source.content) {
            return {
                ...source,
                relevanceScore: 0,
                extractedSections: [],
                keywords: []
            };
        }
        const content = source.content.toLowerCase();
        const foundKeywords = [];
        const keywordPositions = [];
        // Find all keyword occurrences
        for (const keyword of keywords){
            let position = content.indexOf(keyword);
            while(position !== -1){
                keywordPositions.push({
                    keyword,
                    position
                });
                if (!foundKeywords.includes(keyword)) {
                    foundKeywords.push(keyword);
                }
                position = content.indexOf(keyword, position + 1);
            }
        }
        // Calculate relevance score
        const relevanceScore = this.calculateRelevanceScore(foundKeywords.length, keywordPositions.length, keywords.length, source.content.length);
        // Extract relevant sections around keywords
        const extractedSections = this.extractRelevantSections(source.content, keywordPositions);
        return {
            ...source,
            relevanceScore,
            extractedSections,
            keywords: foundKeywords
        };
    }
    /**
   * Calculate relevance score based on keyword matches
   */ calculateRelevanceScore(uniqueKeywordsFound, totalKeywordMatches, totalKeywords, contentLength) {
        // Coverage: what percentage of query keywords were found
        const coverage = totalKeywords > 0 ? uniqueKeywordsFound / totalKeywords : 0;
        // Density: keyword matches per 1000 characters
        const density = totalKeywordMatches / contentLength * 1000;
        // Normalize density (cap at 10 matches per 1000 chars)
        const normalizedDensity = Math.min(density / 10, 1);
        // Combined score (coverage is more important)
        return coverage * 0.7 + normalizedDensity * 0.3;
    }
    /**
   * Extract relevant sections around keyword matches
   */ extractRelevantSections(content, keywordPositions) {
        if (keywordPositions.length === 0) {
            // No keywords found, return beginning of content
            return [
                content.slice(0, this.MIN_CHARS_PER_SOURCE)
            ];
        }
        // Sort positions
        keywordPositions.sort((a, b)=>a.position - b.position);
        // Merge overlapping windows
        const windows = [];
        for (const { position } of keywordPositions){
            const start = Math.max(0, position - this.CONTEXT_WINDOW_SIZE);
            const end = Math.min(content.length, position + this.CONTEXT_WINDOW_SIZE);
            // Check if this window overlaps with the last one
            if (windows.length > 0 && start <= windows[windows.length - 1].end) {
                // Extend the last window
                windows[windows.length - 1].end = end;
            } else {
                // Add new window
                windows.push({
                    start,
                    end
                });
            }
        }
        // Extract sections, ensuring we capture sentence boundaries
        const sections = [];
        for (const window of windows){
            // Extend to sentence boundaries
            let start = window.start;
            let end = window.end;
            // Find previous sentence boundary
            const prevPeriod = content.lastIndexOf('.', start);
            const prevNewline = content.lastIndexOf('\n', start);
            start = Math.max(prevPeriod + 1, prevNewline + 1, 0);
            // Find next sentence boundary
            const nextPeriod = content.indexOf('.', end);
            const nextNewline = content.indexOf('\n', end);
            if (nextPeriod !== -1 || nextNewline !== -1) {
                end = Math.min(nextPeriod !== -1 ? nextPeriod + 1 : content.length, nextNewline !== -1 ? nextNewline : content.length);
            }
            const section = content.slice(start, end).trim();
            if (section) {
                sections.push(section);
            }
        }
        return sections;
    }
    /**
   * Distribute character budget among sources based on relevance
   */ distributeCharacterBudget(sources) {
        // Filter out sources with no relevance
        const relevantSources = sources.filter((s)=>s.relevanceScore > 0);
        if (relevantSources.length === 0) {
            // Fallback: use first few sources
            return sources.slice(0, 5).map((s)=>({
                    ...s,
                    content: s.content?.slice(0, this.MAX_CHARS_PER_SOURCE) || ''
                }));
        }
        // Calculate total relevance
        const totalRelevance = relevantSources.reduce((sum, s)=>sum + s.relevanceScore, 0);
        // Distribute budget proportionally
        let remainingBudget = this.MAX_TOTAL_CHARS;
        const processedResults = [];
        for (const source of relevantSources){
            if (remainingBudget <= 0) break;
            // Calculate this source's share
            const relevanceRatio = source.relevanceScore / totalRelevance;
            const allocatedChars = Math.floor(relevanceRatio * this.MAX_TOTAL_CHARS);
            // Apply min/max constraints
            const targetChars = Math.max(this.MIN_CHARS_PER_SOURCE, Math.min(allocatedChars, this.MAX_CHARS_PER_SOURCE, remainingBudget));
            // Use extracted sections if available, otherwise use full content
            let processedContent;
            if (source.extractedSections.length > 0) {
                // Combine extracted sections
                processedContent = source.extractedSections.join('\n\n[...]\n\n');
                // If still too short, add more content around sections
                if (processedContent.length < targetChars && source.content) {
                    const additionalContent = source.content.slice(0, targetChars - processedContent.length);
                    processedContent = additionalContent + '\n\n[...]\n\n' + processedContent;
                }
            } else {
                // Use beginning of content
                processedContent = source.content?.slice(0, targetChars) || '';
            }
            // Ensure we don't exceed target
            if (processedContent.length > targetChars) {
                processedContent = processedContent.slice(0, targetChars) + '\n[... content truncated]';
            }
            remainingBudget -= processedContent.length;
            processedResults.push({
                ...source,
                content: processedContent
            });
        }
        return processedResults;
    }
    /**
   * Calculate optimal summary length based on source count
   */ calculateSummaryLength(sourceCount) {
        if (sourceCount <= 5) return 4000;
        if (sourceCount <= 10) return 3000;
        if (sourceCount <= 20) return 2000;
        if (sourceCount <= 30) return 1500;
        return 1000;
    }
    /**
   * Summarize a single source using GPT-4o-mini
   */ async summarizeSource(source, query, searchQueries, targetLength, _onProgress// eslint-disable-line @typescript-eslint/no-unused-vars
    ) {
        // If no content, return empty source
        if (!source.content || source.content.length < 100) {
            return {
                ...source,
                relevanceScore: 0,
                extractedSections: [],
                keywords: [],
                summarized: false
            };
        }
        try {
            // No longer emit individual progress events
            // Create a focused prompt for relevance-based summarization
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateText"])({
                model: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$openai$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["openai"])('gpt-4o-mini'),
                prompt: `You are a research assistant helping to extract the most relevant information from a webpage.

User's question: "${query}"
Related search queries: ${searchQueries.join(', ')}

Source title: ${source.title}
Source URL: ${source.url}

Content to analyze:
${source.content.slice(0, 15000)} ${source.content.length > 15000 ? '\n[... content truncated]' : ''}

Instructions:
1. Extract ONLY the information that directly relates to the user's question and search queries
2. Focus on specific facts, data, quotes, and concrete details
3. Preserve important numbers, dates, names, and technical details
4. Maintain the original meaning and context
5. If the content has little relevance to the query, just note that briefly
6. Target length: approximately ${targetLength} characters

Provide a focused summary that would help answer the user's question:`,
                temperature: 0.3,
                maxTokens: Math.ceil(targetLength / 3)
            });
            const summary = result.text.trim();
            // Calculate a simple relevance score based on the summary
            const relevanceScore = this.calculateRelevanceFromSummary(summary, query, searchQueries);
            return {
                ...source,
                content: summary,
                relevanceScore,
                extractedSections: [
                    summary
                ],
                keywords: this.extractKeywords(query, searchQueries),
                summarized: true
            };
        } catch (error) {
            console.warn(`Failed to summarize source ${source.url}:`, error);
            // Fallback to keyword extraction method
            const keywords = this.extractKeywords(query, searchQueries);
            const processed = await this.processSource(source, keywords);
            // Use distributed budget for fallback
            const fallbackSources = await this.distributeCharacterBudget([
                processed
            ]);
            return fallbackSources[0] || processed;
        }
    }
    /**
   * Calculate relevance score from summary
   */ calculateRelevanceFromSummary(summary, query, searchQueries) {
        // Simple heuristic: longer summaries with more specific content are more relevant
        const summaryLength = summary.length;
        // Check if summary indicates low relevance
        const lowRelevancePhrases = [
            'not directly related',
            'no specific information',
            'doesn\'t mention',
            'no relevant content',
            'unrelated to'
        ];
        const summaryLower = summary.toLowerCase();
        const hasLowRelevance = lowRelevancePhrases.some((phrase)=>summaryLower.includes(phrase));
        if (hasLowRelevance) {
            return 0.1; // Very low relevance
        }
        // Check for high relevance indicators
        const highRelevanceIndicators = [
            'specifically mentions',
            'directly addresses',
            'provides detailed',
            'explains how',
            'data shows',
            'research indicates'
        ];
        const hasHighRelevance = highRelevanceIndicators.some((phrase)=>summaryLower.includes(phrase));
        // Calculate score
        let score = Math.min(summaryLength / 2000, 1.0); // Base score from length
        if (hasHighRelevance) {
            score = Math.min(score + 0.3, 1.0);
        }
        // Check keyword density in summary
        const keywords = this.extractKeywords(query, searchQueries);
        const keywordMatches = keywords.filter((keyword)=>summaryLower.includes(keyword.toLowerCase())).length;
        const keywordScore = keywords.length > 0 ? keywordMatches / keywords.length : 0.5;
        // Combined score
        return score * 0.6 + keywordScore * 0.4;
    }
}
}}),
"[project]/lib/config.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// Search Engine Configuration
__turbopack_context__.s({
    "MODEL_CONFIG": (()=>MODEL_CONFIG),
    "SEARCH_CONFIG": (()=>SEARCH_CONFIG),
    "UI_CONFIG": (()=>UI_CONFIG)
});
const SEARCH_CONFIG = {
    // Search Settings
    MAX_SEARCH_QUERIES: 4,
    MAX_SOURCES_PER_SEARCH: 6,
    MAX_SOURCES_TO_SCRAPE: 6,
    // Content Processing
    MIN_CONTENT_LENGTH: 100,
    SUMMARY_CHAR_LIMIT: 100,
    CONTEXT_PREVIEW_LENGTH: 500,
    ANSWER_CHECK_PREVIEW: 2500,
    MAX_SOURCES_TO_CHECK: 10,
    // Retry Logic
    MAX_RETRIES: 2,
    MAX_SEARCH_ATTEMPTS: 3,
    MIN_ANSWER_CONFIDENCE: 0.3,
    EARLY_TERMINATION_CONFIDENCE: 0.8,
    // Timeouts
    SCRAPE_TIMEOUT: 15000,
    // Performance
    SOURCE_ANIMATION_DELAY: 50,
    PARALLEL_SUMMARY_GENERATION: true
};
const UI_CONFIG = {
    ANIMATION_DURATION: 300,
    SOURCE_FADE_DELAY: 50,
    MESSAGE_CYCLE_DELAY: 2000
};
const MODEL_CONFIG = {
    FAST_MODEL: "gpt-4o-mini",
    QUALITY_MODEL: "gpt-4o",
    TEMPERATURE: 0
};
}}),
"[project]/lib/langgraph-search-engine.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "LangGraphSearchEngine": (()=>LangGraphSearchEngine)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@langchain/langgraph/index.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$state$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@langchain/langgraph/dist/graph/state.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$constants$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@langchain/langgraph/dist/constants.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@langchain/langgraph/dist/graph/annotation.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2d$checkpoint$2f$dist$2f$memory$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@langchain/langgraph-checkpoint/dist/memory.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$openai$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@langchain/openai/index.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$openai$2f$dist$2f$chat_models$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@langchain/openai/dist/chat_models.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$messages$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@langchain/core/messages.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@langchain/core/dist/messages/human.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@langchain/core/dist/messages/system.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$context$2d$processor$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/context-processor.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/config.ts [app-rsc] (ecmascript)");
;
;
;
;
;
// Proper LangGraph state using Annotation with reducers
const SearchStateAnnotation = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"].Root({
    // Input fields
    query: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (_, y)=>y ?? "",
        default: ()=>""
    }),
    context: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (_, y)=>y,
        default: ()=>undefined
    }),
    // Process fields
    understanding: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>undefined
    }),
    searchQueries: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>undefined
    }),
    currentSearchIndex: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>0
    }),
    // Results fields - with proper array reducers
    sources: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (existing, update)=>{
            if (!update) return existing;
            // Deduplicate sources by URL
            const sourceMap = new Map();
            [
                ...existing,
                ...update
            ].forEach((source)=>{
                sourceMap.set(source.url, source);
            });
            return Array.from(sourceMap.values());
        },
        default: ()=>[]
    }),
    scrapedSources: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (existing, update)=>{
            if (!update) return existing;
            return [
                ...existing,
                ...update
            ];
        },
        default: ()=>[]
    }),
    processedSources: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>undefined
    }),
    finalAnswer: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>undefined
    }),
    followUpQuestions: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>undefined
    }),
    // Answer tracking
    subQueries: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>undefined
    }),
    searchAttempt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>0
    }),
    // Control fields
    phase: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>'understanding'
    }),
    error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>undefined
    }),
    errorType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>undefined
    }),
    maxRetries: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_RETRIES
    }),
    retryCount: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$annotation$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Annotation"])({
        reducer: (x, y)=>y ?? x,
        default: ()=>0
    })
});
class LangGraphSearchEngine {
    firecrawl;
    contextProcessor;
    graph;
    llm;
    streamingLlm;
    checkpointer;
    constructor(firecrawl, options){
        this.firecrawl = firecrawl;
        this.contextProcessor = new __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$context$2d$processor$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ContextProcessor"]();
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) {
            throw new Error('OPENAI_API_KEY environment variable is not set');
        }
        // Initialize LangChain models
        this.llm = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$openai$2f$dist$2f$chat_models$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ChatOpenAI"]({
            modelName: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["MODEL_CONFIG"].FAST_MODEL,
            temperature: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["MODEL_CONFIG"].TEMPERATURE,
            openAIApiKey: apiKey
        });
        this.streamingLlm = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$openai$2f$dist$2f$chat_models$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ChatOpenAI"]({
            modelName: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["MODEL_CONFIG"].QUALITY_MODEL,
            temperature: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["MODEL_CONFIG"].TEMPERATURE,
            streaming: true,
            openAIApiKey: apiKey
        });
        // Enable checkpointing if requested
        if (options?.enableCheckpointing) {
            this.checkpointer = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2d$checkpoint$2f$dist$2f$memory$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["MemorySaver"]();
        }
        this.graph = this.buildGraph();
    }
    getInitialSteps() {
        return [
            {
                id: 'understanding',
                label: 'Understanding request',
                status: 'pending'
            },
            {
                id: 'planning',
                label: 'Planning search',
                status: 'pending'
            },
            {
                id: 'searching',
                label: 'Searching sources',
                status: 'pending'
            },
            {
                id: 'analyzing',
                label: 'Analyzing content',
                status: 'pending'
            },
            {
                id: 'synthesizing',
                label: 'Synthesizing answer',
                status: 'pending'
            },
            {
                id: 'complete',
                label: 'Complete',
                status: 'pending'
            }
        ];
    }
    buildGraph() {
        // Create closures for helper methods
        const analyzeQuery = this.analyzeQuery.bind(this);
        const scoreContent = this.scoreContent.bind(this);
        const summarizeContent = this.summarizeContent.bind(this);
        const generateStreamingAnswer = this.generateStreamingAnswer.bind(this);
        const generateFollowUpQuestions = this.generateFollowUpQuestions.bind(this);
        const firecrawl = this.firecrawl;
        const contextProcessor = this.contextProcessor;
        const workflow = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$graph$2f$state$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["StateGraph"](SearchStateAnnotation)// Understanding node
        .addNode("understand", async (state, config)=>{
            const eventCallback = config?.configurable?.eventCallback;
            if (eventCallback) {
                eventCallback({
                    type: 'phase-update',
                    phase: 'understanding',
                    message: 'Analyzing your request...'
                });
            }
            try {
                const understanding = await analyzeQuery(state.query, state.context);
                if (eventCallback) {
                    eventCallback({
                        type: 'thinking',
                        message: understanding
                    });
                }
                return {
                    understanding,
                    phase: 'planning'
                };
            } catch (error) {
                return {
                    error: error instanceof Error ? error.message : 'Failed to understand query',
                    errorType: 'llm',
                    phase: 'error'
                };
            }
        })// Planning node
        .addNode("plan", async (state, config)=>{
            const eventCallback = config?.configurable?.eventCallback;
            if (eventCallback) {
                eventCallback({
                    type: 'phase-update',
                    phase: 'planning',
                    message: 'Planning search strategy...'
                });
            }
            try {
                // Extract sub-queries if not already done
                let subQueries = state.subQueries;
                if (!subQueries) {
                    const extractSubQueries = this.extractSubQueries.bind(this);
                    const extracted = await extractSubQueries(state.query);
                    subQueries = extracted.map((sq)=>({
                            question: sq.question,
                            searchQuery: sq.searchQuery,
                            answered: false,
                            confidence: 0,
                            sources: []
                        }));
                }
                // Generate search queries for unanswered questions
                const unansweredQueries = subQueries.filter((sq)=>!sq.answered || sq.confidence < __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MIN_ANSWER_CONFIDENCE);
                if (unansweredQueries.length === 0) {
                    // All questions answered, skip to analysis
                    return {
                        subQueries,
                        phase: 'analyzing'
                    };
                }
                // Use alternative search queries if this is a retry
                let searchQueries;
                if (state.searchAttempt > 0) {
                    const generateAlternativeSearchQueries = this.generateAlternativeSearchQueries.bind(this);
                    searchQueries = await generateAlternativeSearchQueries(subQueries, state.searchAttempt);
                    // Update sub-queries with new search queries
                    let alternativeIndex = 0;
                    subQueries.forEach((sq)=>{
                        if (!sq.answered || sq.confidence < __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MIN_ANSWER_CONFIDENCE) {
                            if (alternativeIndex < searchQueries.length) {
                                sq.searchQuery = searchQueries[alternativeIndex];
                                alternativeIndex++;
                            }
                        }
                    });
                } else {
                    // First attempt - use the search queries from sub-queries
                    searchQueries = unansweredQueries.map((sq)=>sq.searchQuery);
                }
                if (eventCallback) {
                    if (state.searchAttempt === 0) {
                        eventCallback({
                            type: 'thinking',
                            message: searchQueries.length > 3 ? `I detected ${subQueries.length} different questions. I'll search for each one separately.` : `I'll search for information to answer your question.`
                        });
                    } else {
                        eventCallback({
                            type: 'thinking',
                            message: `Trying alternative search strategies for: ${unansweredQueries.map((sq)=>sq.question).join(', ')}`
                        });
                    }
                }
                return {
                    searchQueries,
                    subQueries,
                    currentSearchIndex: 0,
                    phase: 'searching'
                };
            } catch (error) {
                return {
                    error: error instanceof Error ? error.message : 'Failed to plan search',
                    errorType: 'llm',
                    phase: 'error'
                };
            }
        })// Search node (handles one search at a time)
        .addNode("search", async (state, config)=>{
            const eventCallback = config?.configurable?.eventCallback;
            const searchQueries = state.searchQueries || [];
            const currentIndex = state.currentSearchIndex || 0;
            if (currentIndex === 0 && eventCallback) {
                eventCallback({
                    type: 'phase-update',
                    phase: 'searching',
                    message: 'Searching the web...'
                });
            }
            if (currentIndex >= searchQueries.length) {
                return {
                    phase: 'scrape'
                };
            }
            const searchQuery = searchQueries[currentIndex];
            if (eventCallback) {
                eventCallback({
                    type: 'searching',
                    query: searchQuery,
                    index: currentIndex + 1,
                    total: searchQueries.length
                });
            }
            try {
                const results = await firecrawl.search(searchQuery, {
                    limit: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_SOURCES_PER_SEARCH,
                    scrapeOptions: {
                        formats: [
                            'markdown'
                        ]
                    }
                });
                const newSources = results.data.map((r)=>({
                        url: r.url,
                        title: r.title,
                        content: r.markdown || r.content || '',
                        quality: 0
                    }));
                if (eventCallback) {
                    eventCallback({
                        type: 'found',
                        sources: newSources,
                        query: searchQuery
                    });
                }
                // Process sources in parallel for better performance
                if (__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].PARALLEL_SUMMARY_GENERATION) {
                    await Promise.all(newSources.map(async (source)=>{
                        if (eventCallback) {
                            eventCallback({
                                type: 'source-processing',
                                url: source.url,
                                title: source.title,
                                stage: 'browsing'
                            });
                        }
                        // Score the content
                        source.quality = scoreContent(source.content || '', state.query);
                        // Generate summary if content is available
                        if (source.content && source.content.length > __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MIN_CONTENT_LENGTH) {
                            const summary = await summarizeContent(source.content, searchQuery);
                            // Store the summary in the source object
                            if (summary && !summary.toLowerCase().includes('no specific')) {
                                source.summary = summary;
                                if (eventCallback) {
                                    eventCallback({
                                        type: 'source-complete',
                                        url: source.url,
                                        summary: summary
                                    });
                                }
                            }
                        }
                    }));
                } else {
                    // Original sequential processing
                    for (const source of newSources){
                        if (eventCallback) {
                            eventCallback({
                                type: 'source-processing',
                                url: source.url,
                                title: source.title,
                                stage: 'browsing'
                            });
                        }
                        // Small delay for animation
                        await new Promise((resolve)=>setTimeout(resolve, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].SOURCE_ANIMATION_DELAY));
                        // Score the content
                        source.quality = scoreContent(source.content || '', state.query);
                        // Generate summary if content is available
                        if (source.content && source.content.length > __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MIN_CONTENT_LENGTH) {
                            const summary = await summarizeContent(source.content, searchQuery);
                            // Store the summary in the source object
                            if (summary && !summary.toLowerCase().includes('no specific')) {
                                source.summary = summary;
                                if (eventCallback) {
                                    eventCallback({
                                        type: 'source-complete',
                                        url: source.url,
                                        summary: summary
                                    });
                                }
                            }
                        }
                    }
                }
                return {
                    sources: newSources,
                    currentSearchIndex: currentIndex + 1
                };
            } catch  {
                return {
                    currentSearchIndex: currentIndex + 1,
                    errorType: 'search'
                };
            }
        })// Scraping node
        .addNode("scrape", async (state, config)=>{
            const eventCallback = config?.configurable?.eventCallback;
            const sourcesToScrape = state.sources?.filter((s)=>!s.content || s.content.length < __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MIN_CONTENT_LENGTH) || [];
            const newScrapedSources = [];
            // Sources with content were already processed in search node, just pass them through
            const sourcesWithContent = state.sources?.filter((s)=>s.content && s.content.length >= __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MIN_CONTENT_LENGTH) || [];
            newScrapedSources.push(...sourcesWithContent);
            // Then scrape sources without content
            for(let i = 0; i < Math.min(sourcesToScrape.length, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_SOURCES_TO_SCRAPE); i++){
                const source = sourcesToScrape[i];
                if (eventCallback) {
                    eventCallback({
                        type: 'scraping',
                        url: source.url,
                        index: newScrapedSources.length + 1,
                        total: sourcesWithContent.length + Math.min(sourcesToScrape.length, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_SOURCES_TO_SCRAPE),
                        query: state.query
                    });
                }
                try {
                    const scraped = await firecrawl.scrapeUrl(source.url, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].SCRAPE_TIMEOUT);
                    if (scraped.success && scraped.markdown) {
                        const enrichedSource = {
                            ...source,
                            content: scraped.markdown,
                            quality: scoreContent(scraped.markdown, state.query)
                        };
                        newScrapedSources.push(enrichedSource);
                        // Show processing animation
                        if (eventCallback) {
                            eventCallback({
                                type: 'source-processing',
                                url: source.url,
                                title: source.title,
                                stage: 'browsing'
                            });
                        }
                        await new Promise((resolve)=>setTimeout(resolve, 150));
                        const summary = await summarizeContent(scraped.markdown, state.query);
                        if (summary) {
                            enrichedSource.summary = summary;
                            if (eventCallback) {
                                eventCallback({
                                    type: 'source-complete',
                                    url: source.url,
                                    summary: summary
                                });
                            }
                        }
                    } else if (scraped.error === 'timeout') {
                        if (eventCallback) {
                            eventCallback({
                                type: 'thinking',
                                message: `${new URL(source.url).hostname} is taking too long to respond, moving on...`
                            });
                        }
                    }
                } catch  {
                    if (eventCallback) {
                        eventCallback({
                            type: 'thinking',
                            message: `Couldn't access ${new URL(source.url).hostname}, trying other sources...`
                        });
                    }
                }
            }
            return {
                scrapedSources: newScrapedSources,
                phase: 'analyzing'
            };
        })// Analyzing node
        .addNode("analyze", async (state, config)=>{
            const eventCallback = config?.configurable?.eventCallback;
            if (eventCallback) {
                eventCallback({
                    type: 'phase-update',
                    phase: 'analyzing',
                    message: 'Analyzing gathered information...'
                });
            }
            // Combine sources and remove duplicates by URL
            const sourceMap = new Map();
            // Add all sources (not just those with long content, since summaries contain key info)
            (state.sources || []).forEach((s)=>sourceMap.set(s.url, s));
            // Add scraped sources (may override with better content)
            (state.scrapedSources || []).forEach((s)=>sourceMap.set(s.url, s));
            const allSources = Array.from(sourceMap.values());
            // Check which questions have been answered
            if (state.subQueries) {
                const checkAnswersInSources = this.checkAnswersInSources.bind(this);
                const updatedSubQueries = await checkAnswersInSources(state.subQueries, allSources);
                const answeredCount = updatedSubQueries.filter((sq)=>sq.answered).length;
                const totalQuestions = updatedSubQueries.length;
                const searchAttempt = (state.searchAttempt || 0) + 1;
                // Check if we have partial answers with decent confidence
                const partialAnswers = updatedSubQueries.filter((sq)=>sq.confidence >= 0.3);
                const hasPartialInfo = partialAnswers.length > answeredCount;
                if (eventCallback) {
                    if (answeredCount === totalQuestions) {
                        eventCallback({
                            type: 'thinking',
                            message: `Found answers to all ${totalQuestions} questions across ${allSources.length} sources`
                        });
                    } else if (answeredCount > 0) {
                        eventCallback({
                            type: 'thinking',
                            message: `Found answers to ${answeredCount} of ${totalQuestions} questions. Still missing: ${updatedSubQueries.filter((sq)=>!sq.answered).map((sq)=>sq.question).join(', ')}`
                        });
                    } else if (searchAttempt >= __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_SEARCH_ATTEMPTS) {
                        // Only show "could not find" message when we've exhausted all attempts
                        eventCallback({
                            type: 'thinking',
                            message: `Could not find specific answers in ${allSources.length} sources. The information may not be publicly available.`
                        });
                    } else if (hasPartialInfo && searchAttempt >= 3) {
                        // If we have partial info and tried 3+ times, stop searching
                        eventCallback({
                            type: 'thinking',
                            message: `Found partial information. Moving forward with what's available.`
                        });
                    } else {
                        // For intermediate attempts, show a different message
                        eventCallback({
                            type: 'thinking',
                            message: `Searching for more specific information...`
                        });
                    }
                }
                // If we haven't found all answers and haven't exceeded attempts, try again
                // BUT stop if we have partial info and already tried 2+ times
                if (answeredCount < totalQuestions && searchAttempt < __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_SEARCH_ATTEMPTS && !(hasPartialInfo && searchAttempt >= 2)) {
                    return {
                        sources: allSources,
                        subQueries: updatedSubQueries,
                        searchAttempt,
                        phase: 'planning'
                    };
                }
                // Otherwise proceed with what we have
                try {
                    const processedSources = await contextProcessor.processSources(state.query, allSources, state.searchQueries || []);
                    return {
                        sources: allSources,
                        processedSources,
                        subQueries: updatedSubQueries,
                        searchAttempt,
                        phase: 'synthesizing'
                    };
                } catch  {
                    return {
                        sources: allSources,
                        processedSources: allSources,
                        subQueries: updatedSubQueries,
                        searchAttempt,
                        phase: 'synthesizing'
                    };
                }
            } else {
                // Fallback for queries without sub-queries
                if (eventCallback && allSources.length > 0) {
                    eventCallback({
                        type: 'thinking',
                        message: `Found ${allSources.length} sources with quality information`
                    });
                }
                try {
                    const processedSources = await contextProcessor.processSources(state.query, allSources, state.searchQueries || []);
                    return {
                        sources: allSources,
                        processedSources,
                        phase: 'synthesizing'
                    };
                } catch  {
                    return {
                        sources: allSources,
                        processedSources: allSources,
                        phase: 'synthesizing'
                    };
                }
            }
        })// Synthesizing node with streaming
        .addNode("synthesize", async (state, config)=>{
            const eventCallback = config?.configurable?.eventCallback;
            if (eventCallback) {
                eventCallback({
                    type: 'phase-update',
                    phase: 'synthesizing',
                    message: 'Creating comprehensive answer...'
                });
            }
            try {
                const sourcesToUse = state.processedSources || state.sources || [];
                const answer = await generateStreamingAnswer(state.query, sourcesToUse, (chunk)=>{
                    if (eventCallback) {
                        eventCallback({
                            type: 'content-chunk',
                            chunk
                        });
                    }
                }, state.context);
                // Generate follow-up questions
                const followUpQuestions = await generateFollowUpQuestions(state.query, answer, sourcesToUse, state.context);
                return {
                    finalAnswer: answer,
                    followUpQuestions,
                    phase: 'complete'
                };
            } catch (error) {
                return {
                    error: error instanceof Error ? error.message : 'Failed to generate answer',
                    errorType: 'llm',
                    phase: 'error'
                };
            }
        })// Error handling node
        .addNode("handleError", async (state, config)=>{
            const eventCallback = config?.configurable?.eventCallback;
            if (eventCallback) {
                eventCallback({
                    type: 'error',
                    error: state.error || 'An unknown error occurred',
                    errorType: state.errorType
                });
            }
            // Retry logic based on error type
            if ((state.retryCount || 0) < (state.maxRetries || __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_RETRIES)) {
                // Different retry strategies based on error type
                const retryPhase = state.errorType === 'search' ? 'searching' : 'understanding';
                return {
                    retryCount: (state.retryCount || 0) + 1,
                    phase: retryPhase,
                    error: undefined,
                    errorType: undefined
                };
            }
            return {
                phase: 'error'
            };
        })// Complete node
        .addNode("complete", async (state, config)=>{
            const eventCallback = config?.configurable?.eventCallback;
            if (eventCallback) {
                eventCallback({
                    type: 'phase-update',
                    phase: 'complete',
                    message: 'Search complete!'
                });
                eventCallback({
                    type: 'final-result',
                    content: state.finalAnswer || '',
                    sources: state.sources || [],
                    followUpQuestions: state.followUpQuestions
                });
            }
            return {
                phase: 'complete'
            };
        });
        // Add edges with proper conditional routing
        workflow.addEdge(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$constants$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["START"], "understand").addConditionalEdges("understand", (state)=>state.phase === 'error' ? "handleError" : "plan", {
            handleError: "handleError",
            plan: "plan"
        }).addConditionalEdges("plan", (state)=>state.phase === 'error' ? "handleError" : "search", {
            handleError: "handleError",
            search: "search"
        }).addConditionalEdges("search", (state)=>{
            if (state.phase === 'error') return "handleError";
            if ((state.currentSearchIndex || 0) < (state.searchQueries?.length || 0)) {
                return "search"; // Continue searching
            }
            return "scrape"; // Move to scraping
        }, {
            handleError: "handleError",
            search: "search",
            scrape: "scrape"
        }).addConditionalEdges("scrape", (state)=>state.phase === 'error' ? "handleError" : "analyze", {
            handleError: "handleError",
            analyze: "analyze"
        }).addConditionalEdges("analyze", (state)=>{
            if (state.phase === 'error') return "handleError";
            if (state.phase === 'planning') return "plan"; // Retry with new searches
            return "synthesize";
        }, {
            handleError: "handleError",
            plan: "plan",
            synthesize: "synthesize"
        }).addConditionalEdges("synthesize", (state)=>state.phase === 'error' ? "handleError" : "complete", {
            handleError: "handleError",
            complete: "complete"
        }).addConditionalEdges("handleError", (state)=>state.phase === 'error' ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$constants$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["END"] : "understand", {
            [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$constants$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["END"]]: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$constants$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["END"],
            understand: "understand"
        }).addEdge("complete", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$langgraph$2f$dist$2f$constants$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["END"]);
        // Compile with optional checkpointing
        return workflow.compile(this.checkpointer ? {
            checkpointer: this.checkpointer
        } : undefined);
    }
    async search(query, onEvent, context, checkpointId) {
        try {
            const initialState = {
                query,
                context,
                sources: [],
                scrapedSources: [],
                processedSources: undefined,
                phase: 'understanding',
                currentSearchIndex: 0,
                maxRetries: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_RETRIES,
                retryCount: 0,
                understanding: undefined,
                searchQueries: undefined,
                finalAnswer: undefined,
                followUpQuestions: undefined,
                error: undefined,
                errorType: undefined,
                subQueries: undefined,
                searchAttempt: 0
            };
            // Configure with event callback
            const config = {
                configurable: {
                    eventCallback: onEvent,
                    ...checkpointId && this.checkpointer ? {
                        thread_id: checkpointId
                    } : {}
                }
            };
            // Invoke the graph with increased recursion limit
            await this.graph.invoke(initialState, {
                ...config,
                recursionLimit: 35 // Increased from default 25 to handle MAX_SEARCH_ATTEMPTS=5
            });
        } catch (error) {
            onEvent({
                type: 'error',
                error: error instanceof Error ? error.message : 'Search failed',
                errorType: 'unknown'
            });
        }
    }
    // Get current date for context
    getCurrentDateContext() {
        const now = new Date();
        const dateStr = now.toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        const year = now.getFullYear();
        const month = now.getMonth() + 1;
        return `Today's date is ${dateStr}. The current year is ${year} and it's currently ${month}/${year}.`;
    }
    // Pure helper methods (no side effects)
    async analyzeQuery(query, context) {
        let contextPrompt = '';
        if (context && context.length > 0) {
            contextPrompt = '\n\nPrevious conversation:\n';
            context.forEach((c)=>{
                contextPrompt += `User: ${c.query}\nAssistant: ${c.response.substring(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].CONTEXT_PREVIEW_LENGTH)}...\n\n`;
            });
        }
        const messages = [
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SystemMessage"](`${this.getCurrentDateContext()}

Analyze this search query and explain what you understand the user is looking for.

Instructions:
- Start with a clear, concise title (e.g., "Researching egg shortage" or "Understanding climate change impacts")
- Then explain in 1-2 sentences what aspects of the topic the user wants to know about
- If this relates to previous questions, acknowledge that connection
- Finally, mention that you'll search for information to help answer their question
- Only mention searching for "latest" information if the query is explicitly about recent events or current trends

Keep it natural and conversational, showing you truly understand their request.`),
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HumanMessage"](`Query: "${query}"${contextPrompt}`)
        ];
        const response = await this.llm.invoke(messages);
        return response.content.toString();
    }
    async checkAnswersInSources(subQueries, sources) {
        if (sources.length === 0) return subQueries;
        const messages = [
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SystemMessage"](`Check which questions have been answered by the provided sources.

For each question, determine:
1. If the sources contain a direct answer
2. The confidence level (0.0-1.0) that the question was fully answered
3. A brief answer summary if found

Guidelines:
- For "who" questions about people/founders: Mark as answered (0.8+ confidence) if you find names of specific people
- For "what" questions: Mark as answered (0.8+ confidence) if you find the specific information requested
- For "when" questions: Mark as answered (0.8+ confidence) if you find dates or time periods
- For "how many" questions: Require specific numbers (0.8+ confidence)
- For comparison questions: Require information about all items being compared
- If sources clearly answer the question but lack some minor details, use medium confidence (0.6-0.7)
- If sources mention the topic but don't answer the specific question, use low confidence (< 0.3)

Version number matching:
- "0528" in the question matches "0528", "-0528", "May 28", or "May 28, 2025" in sources
- Example: Question about "DeepSeek R1 0528" is ANSWERED if sources mention:
  - "DeepSeek R1-0528" (exact match)
  - "DeepSeek R1 was updated on May 28" (date match)
  - "DeepSeek's R1 model was updated on May 28, 2025" (date match)
- Hyphens and spaces in version numbers should be ignored when matching
- If the summary mentions the product and a matching date/version, that's a full answer

Special cases:
- If asking about a product/model with a version number (e.g., "ModelX v2.5.1" or "Product 0528"), check BOTH:
  1. If sources mention the EXACT version → mark as answered with high confidence (0.8+)
  2. If sources only mention the base product → mark as answered with medium confidence (0.6+)
- Example: Question "What is ProductX 1234?" 
  - If sources mention "ProductX 1234" specifically → confidence: 0.9
  - If sources only mention "ProductX" → confidence: 0.6
- IMPORTANT: For questions like "What is DeepSeek R1 0528?", if sources contain "DeepSeek R1-0528" or "DeepSeek R1 0528", that's a DIRECT match (confidence 0.9+)
- If multiple sources contradict whether something exists, use low confidence (0.3) but still provide what information was found

Important: Be generous in recognizing answers. If the source clearly provides the information asked for (e.g., "The founders are X, Y, and Z"), mark it as answered with high confidence.

Return ONLY a JSON array, no markdown formatting or code blocks:
[
  {
    "question": "the original question",
    "answered": true/false,
    "confidence": 0.0-1.0,
    "answer": "brief answer if found",
    "sources": ["urls that contain the answer"]
  }
]`),
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HumanMessage"](`Questions to check:
${subQueries.map((sq)=>sq.question).join('\n')}

Sources:
${sources.slice(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_SOURCES_TO_CHECK).map((s)=>{
                let sourceInfo = `URL: ${s.url}\nTitle: ${s.title}\n`;
                // Include summary if available (this is the key insight from the search)
                if (s.summary) {
                    sourceInfo += `Summary: ${s.summary}\n`;
                }
                // Include content preview
                if (s.content) {
                    sourceInfo += `Content: ${s.content.slice(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].ANSWER_CHECK_PREVIEW)}\n`;
                }
                return sourceInfo;
            }).join('\n---\n')}`)
        ];
        try {
            const response = await this.llm.invoke(messages);
            let content = response.content.toString();
            // Strip markdown code blocks if present
            content = content.replace(/```json\s*/g, '').replace(/```\s*$/g, '').trim();
            const results = JSON.parse(content);
            // Update sub-queries with results
            return subQueries.map((sq)=>{
                const result = results.find((r)=>r.question === sq.question);
                if (result && result.confidence > sq.confidence) {
                    return {
                        ...sq,
                        answered: result.confidence >= __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MIN_ANSWER_CONFIDENCE,
                        answer: result.answer,
                        confidence: result.confidence,
                        sources: [
                            ...new Set([
                                ...sq.sources,
                                ...result.sources || []
                            ])
                        ]
                    };
                }
                return sq;
            });
        } catch (error) {
            console.error('Error checking answers:', error);
            return subQueries;
        }
    }
    async extractSubQueries(query) {
        const messages = [
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SystemMessage"](`Extract the individual factual questions from this query. Each question should be something that can be definitively answered.

IMPORTANT: 
- When the user mentions something with a version/number (like "deepseek r1 0528"), include the FULL version in the question
- For the search query, you can simplify slightly but keep key identifiers
- Example: "deepseek r1 0528" → question: "What is DeepSeek R1 0528?", searchQuery: "DeepSeek R1 0528"

Examples:
"Who founded Anthropic and when" → 
[
  {"question": "Who founded Anthropic?", "searchQuery": "Anthropic founders"},
  {"question": "When was Anthropic founded?", "searchQuery": "Anthropic founded date year"}
]

"What is OpenAI's Q3 2024 revenue and who is their VP of Infrastructure" →
[
  {"question": "What was OpenAI's Q3 2024 revenue?", "searchQuery": "OpenAI Q3 2024 revenue earnings"},
  {"question": "Who is OpenAI's VP of Infrastructure?", "searchQuery": "OpenAI VP Infrastructure executive team"}
]

"Tell me about Product A + Model B version 123" →
[
  {"question": "What is Product A?", "searchQuery": "Product A features"},
  {"question": "What is Model B version 123?", "searchQuery": "Model B"}
]

"Who founded Company X, compare Product A and Product B, and tell me about Technology Y + Model Z 1234" →
[
  {"question": "Who founded Company X?", "searchQuery": "Company X founders"},
  {"question": "How do Product A and Product B compare?", "searchQuery": "Product A vs Product B comparison"},
  {"question": "What is Technology Y?", "searchQuery": "Technology Y features"},
  {"question": "What is Model Z 1234?", "searchQuery": "Model Z"}
]

Important: 
- For comparison requests, create a single question/search that covers both items
- If a term looks like it might be a model name with a version/date (like "R1 0528"), treat it as a single entity first, but create a search query that focuses on the main product name
- Keep the number of sub-queries reasonable (aim for 3-5 max)

Return ONLY a JSON array of {question, searchQuery} objects.`),
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HumanMessage"](`Query: "${query}"`)
        ];
        try {
            const response = await this.llm.invoke(messages);
            return JSON.parse(response.content.toString());
        } catch  {
            // Fallback: treat as single query
            return [
                {
                    question: query,
                    searchQuery: query
                }
            ];
        }
    }
    // This method was removed as it's not used in the current implementation
    // Search queries are now generated from sub-queries in the plan node
    async generateAlternativeSearchQueries(subQueries, previousAttempts) {
        const unansweredQueries = subQueries.filter((sq)=>!sq.answered || sq.confidence < __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MIN_ANSWER_CONFIDENCE);
        // If we're on attempt 3 and still searching for the same thing, just give up on that specific query
        if (previousAttempts >= 2) {
            const problematicQueries = unansweredQueries.filter((sq)=>{
                // Check if the question contains a version number or specific identifier that might not exist
                const hasVersionPattern = /\b\d{3,4}\b|\bv\d+\.\d+|\bversion\s+\d+/i.test(sq.question);
                const hasFailedMultipleTimes = previousAttempts >= 2;
                return hasVersionPattern && hasFailedMultipleTimes;
            });
            if (problematicQueries.length > 0) {
                // Return generic searches that might find partial info
                return problematicQueries.map((sq)=>{
                    const baseTerm = sq.question.replace(/0528|specific version/gi, '').trim();
                    return baseTerm.substring(0, 50); // Keep it short
                });
            }
        }
        const messages = [
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SystemMessage"](`${this.getCurrentDateContext()}

Generate ALTERNATIVE search queries for questions that weren't answered in previous attempts.

Previous search attempts: ${previousAttempts}
Previous queries that didn't find answers:
${unansweredQueries.map((sq)=>`- Question: "${sq.question}"\n  Previous search: "${sq.searchQuery}"`).join('\n')}

IMPORTANT: If searching for something with a specific version/date that keeps failing (like "R1 0528"), try searching for just the base product without the version.

Generate NEW search queries using these strategies:
1. Try broader or more general terms
2. Try different phrasings or synonyms
3. Remove specific qualifiers (like years or versions) if they're too restrictive
4. Try searching for related concepts that might contain the answer
5. For products that might not exist, search for the company or base product name

Examples of alternative searches:
- Original: "ModelX 2024.05" → Alternative: "ModelX latest version"
- Original: "OpenAI Q3 2024 revenue" → Alternative: "OpenAI financial results 2024"
- Original: "iPhone 15 Pro features" → Alternative: "latest iPhone specifications"

Return one alternative search query per unanswered question, one per line.`),
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HumanMessage"](`Generate alternative searches for these ${unansweredQueries.length} unanswered questions.`)
        ];
        try {
            const response = await this.llm.invoke(messages);
            const result = response.content.toString();
            const queries = result.split('\n').map((q)=>q.trim()).map((q)=>q.replace(/^["']|["']$/g, '')).map((q)=>q.replace(/^\d+\.\s*/, '')).map((q)=>q.replace(/^[-*#]\s*/, '')).filter((q)=>q.length > 0).filter((q)=>!q.match(/^```/)).filter((q)=>q.length > 3);
            return queries.slice(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_SEARCH_QUERIES);
        } catch  {
            // Fallback: return original queries with slight modifications
            return unansweredQueries.map((sq)=>sq.searchQuery + " news reports").slice(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].MAX_SEARCH_QUERIES);
        }
    }
    scoreContent(content, query) {
        const queryWords = query.toLowerCase().split(' ');
        const contentLower = content.toLowerCase();
        let score = 0;
        for (const word of queryWords){
            if (contentLower.includes(word)) score += 0.2;
        }
        return Math.min(score, 1);
    }
    async summarizeContent(content, query) {
        try {
            const messages = [
                new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SystemMessage"](`${this.getCurrentDateContext()}

Extract ONE key finding from this content that's SPECIFICALLY relevant to the search query.

CRITICAL: Only summarize information that directly relates to the search query.
- If searching for "Samsung phones", only mention Samsung phone information
- If searching for "Firecrawl founders", only mention founder information
- If no relevant information is found, just return the most relevant fact from the page

Instructions:
- Return just ONE sentence with a specific finding
- Include numbers, dates, or specific details when available
- Keep it under ${__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$config$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEARCH_CONFIG"].SUMMARY_CHAR_LIMIT} characters
- Don't say "No relevant information was found" - find something relevant to the current search`),
                new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HumanMessage"](`Query: "${query}"\n\nContent: ${content.slice(0, 2000)}`)
            ];
            const response = await this.llm.invoke(messages);
            return response.content.toString().trim();
        } catch  {
            return '';
        }
    }
    async generateStreamingAnswer(query, sources, onChunk, context) {
        const sourcesText = sources.map((s, i)=>{
            if (!s.content) return `[${i + 1}] ${s.title}\n[No content available]`;
            return `[${i + 1}] ${s.title}\n${s.content}`;
        }).join('\n\n');
        let contextPrompt = '';
        if (context && context.length > 0) {
            contextPrompt = '\n\nPrevious conversation for context:\n';
            context.forEach((c)=>{
                contextPrompt += `User: ${c.query}\nAssistant: ${c.response.substring(0, 300)}...\n\n`;
            });
        }
        const messages = [
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SystemMessage"](`${this.getCurrentDateContext()}

Answer the user's question based on the provided sources. Provide a clear, comprehensive answer with citations [1], [2], etc. Use markdown formatting for better readability. If this question relates to previous topics discussed, make connections where relevant.`),
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HumanMessage"](`Question: "${query}"${contextPrompt}\n\nBased on these sources:\n${sourcesText}`)
        ];
        let fullText = '';
        try {
            const stream = await this.streamingLlm.stream(messages);
            for await (const chunk of stream){
                const content = chunk.content;
                if (typeof content === 'string') {
                    fullText += content;
                    onChunk(content);
                }
            }
        } catch  {
            // Fallback to non-streaming if streaming fails
            const response = await this.llm.invoke(messages);
            fullText = response.content.toString();
            onChunk(fullText);
        }
        return fullText;
    }
    async generateFollowUpQuestions(originalQuery, answer, _sources, context) {
        try {
            let contextPrompt = '';
            if (context && context.length > 0) {
                contextPrompt = '\n\nPrevious conversation topics:\n';
                context.forEach((c)=>{
                    contextPrompt += `- ${c.query}\n`;
                });
                contextPrompt += '\nConsider the full conversation flow when generating follow-ups.\n';
            }
            const messages = [
                new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SystemMessage"](`${this.getCurrentDateContext()}

Based on this search query and answer, generate 3 relevant follow-up questions that the user might want to explore next.

Instructions:
- Generate exactly 3 follow-up questions
- Each question should explore a different aspect or dig deeper into the topic
- Questions should be natural and conversational
- They should build upon the information provided in the answer
- Make them specific and actionable
- Keep each question under 80 characters
- Return only the questions, one per line, no numbering or bullets
- Consider the entire conversation context when generating questions
- Only include time-relevant questions if the original query was about current events or trends

Examples of good follow-up questions:
- "How does this compare to [alternative]?"
- "Can you explain [technical term] in more detail?"
- "What are the practical applications of this?"
- "What are the main benefits and drawbacks?"
- "How is this typically implemented?"`),
                new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HumanMessage"](`Original query: "${originalQuery}"\n\nAnswer summary: ${answer.length > 1000 ? answer.slice(0, 1000) + '...' : answer}${contextPrompt}`)
            ];
            const response = await this.llm.invoke(messages);
            const questions = response.content.toString().split('\n').map((q)=>q.trim()).filter((q)=>q.length > 0 && q.length < 80).slice(0, 3);
            return questions.length > 0 ? questions : [];
        } catch  {
            return [];
        }
    }
}
}}),
"[project]/app/search.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"703e71a6385694f38b3fe9203560079111227c42e7":"search"},"",""] */ __turbopack_context__.s({
    "search": (()=>search)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$rsc$2f$dist$2f$rsc$2d$server$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ai/rsc/dist/rsc-server.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firecrawl$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/firecrawl.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$langgraph$2d$search$2d$engine$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/langgraph-search-engine.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
;
async function search(query, context, apiKey) {
    const stream = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$rsc$2f$dist$2f$rsc$2d$server$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createStreamableValue"])();
    // Create FirecrawlClient with API key if provided
    const firecrawl = new __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firecrawl$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["FirecrawlClient"](apiKey);
    const searchEngine = new __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$langgraph$2d$search$2d$engine$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LangGraphSearchEngine"](firecrawl);
    // Run search in background
    (async ()=>{
        try {
            // Stream events as they happen
            await searchEngine.search(query, (event)=>{
                stream.update(event);
            }, context);
            stream.done();
        } catch (error) {
            stream.error(error);
        }
    })();
    return {
        stream: stream.value
    };
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    search
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(search, "703e71a6385694f38b3fe9203560079111227c42e7", null);
}}),
"[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/app/search.tsx [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$search$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/search.tsx [app-rsc] (ecmascript)");
;
}}),
"[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/app/search.tsx [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$search$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/search.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$app$2f$search$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => "[project]/app/search.tsx [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/app/search.tsx [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <exports>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "703e71a6385694f38b3fe9203560079111227c42e7": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$search$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["search"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$search$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/search.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$app$2f$search$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => "[project]/app/search.tsx [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/app/search.tsx [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "703e71a6385694f38b3fe9203560079111227c42e7": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$app$2f$search$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["703e71a6385694f38b3fe9203560079111227c42e7"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$app$2f$search$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => "[project]/app/search.tsx [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <module evaluation>');
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$app$2f$search$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => "[project]/app/search.tsx [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <exports>');
}}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/app/chat.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Chat": (()=>Chat)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const Chat = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Chat() from the server but Chat is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/chat.tsx <module evaluation>", "Chat");
}}),
"[project]/app/chat.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Chat": (()=>Chat)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const Chat = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Chat() from the server but Chat is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/chat.tsx", "Chat");
}}),
"[project]/app/chat.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$chat$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/app/chat.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$chat$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/app/chat.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$chat$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/app/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$chat$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/chat.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
;
;
;
function Home() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "px-4 sm:px-6 lg:px-8 py-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-4xl mx-auto flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "https://firecrawl.dev",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                src: "/Tata_Consultancy_Services_old_logo.svg.png",
                                alt: "TCS Logo",
                                width: 113,
                                height: 24,
                                className: "w-[113px] h-auto"
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 15,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 10,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "https://github.com/mendableai/firesearch",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "justify-center whitespace-nowrap ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none rounded-[10px] text-sm transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-50 bg-[#36322F] text-[#fff] hover:bg-[#4a4542] disabled:bg-[#8c8885] disabled:hover:bg-[#8c8885] [box-shadow:inset_0px_-2.108433723449707px_0px_0px_#171310,_0px_1.2048193216323853px_6.325301647186279px_0px_rgba(58,_33,_8,_58%)] hover:translate-y-[1px] hover:scale-[0.98] hover:[box-shadow:inset_0px_-1px_0px_0px_#171310,_0px_1px_3px_0px_rgba(58,_33,_8,_40%)] active:translate-y-[2px] active:scale-[0.97] active:[box-shadow:inset_0px_1px_1px_0px_#171310,_0px_1px_2px_0px_rgba(58,_33,_8,_30%)] disabled:shadow-none disabled:hover:translate-y-0 disabled:hover:scale-100 h-10 px-4 py-2 font-medium flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    viewBox: "0 0 16 16",
                                    fill: "currentColor",
                                    className: "w-4 h-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 30,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 29,
                                    columnNumber: 13
                                }, this),
                                "Use this template"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 9,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 8,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 sm:px-6 lg:px-8 pt-8 pb-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-4xl mx-auto text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-[2.5rem] lg:text-[3.8rem] text-[#36322F] dark:text-white font-semibold tracking-tight leading-[0.9] opacity-0 animate-fade-up [animation-duration:500ms] [animation-delay:200ms] [animation-fill-mode:forwards]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "relative px-1 text-transparent bg-clip-text bg-gradient-to-tr from-red-600 to-yellow-500 inline-flex justify-center items-center",
                                    children: "TCS DeepSearch  Tool"
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 41,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "block leading-[1.1] opacity-0 animate-fade-up [animation-duration:500ms] [animation-delay:400ms] [animation-fill-mode:forwards]",
                                    children: "Deep Research"
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 44,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 40,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-6 text-lg text-zinc-600 dark:text-zinc-400 opacity-0 animate-fade-up [animation-duration:500ms] [animation-delay:600ms] [animation-fill-mode:forwards]",
                            children: "AI-powered search powered by Multiple Search Engines and LangGraph"
                        }, void 0, false, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 39,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$chat$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Chat"], {}, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 57,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
}}),
"[project]/app/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__d0f68979._.js.map