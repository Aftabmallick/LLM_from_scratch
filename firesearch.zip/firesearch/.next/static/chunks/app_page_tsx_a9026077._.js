(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_1bbbcec2._.js",
  "static/chunks/node_modules_5b1559dd._.js"
],
    source: "dynamic"
});
